package main;

import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;


import programa1.Aluno;
import programa1.Telefone;

public class Principal {
	
	private static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		
		 List<Aluno> listaDeAlunos = new ArrayList<>();
		
		
	
		
		 System.out.println("--- CADASTROS ---");
	       
			for (int i = 0; i < 10; i++) {
	            System.out.println("\nCadastrando  " + (i + 1) + "/" + 10);
	            listaDeAlunos.add(lerAluno());
	        }

	        System.out.println("--LISTA COMPLETA DOS ALUNOS--");
	        imprimirLista(listaDeAlunos);
	}
		
	        public static Aluno lerAluno() {
	        	
		        System.out.print("Digite o nome: ");
				String nome = scanner.nextLine();

		        System.out.print("Digite a idade: ");
		        int idade = Integer.parseInt(scanner.nextLine());

		        System.out.print("Informe o cpf : ");
		        String cpf = scanner.nextLine();
		        

		        Aluno aluno = new Aluno(nome, idade, cpf);

		     
		            System.out.print("Digite seu DDD: ");
		            String codigoArea = scanner.nextLine();
		            
		            System.out.print("Digite seu Numero: ");
		            String numero = scanner.nextLine();
		            
		            aluno.adicionarTelefone(new Telefone(codigoArea, numero));
		        

		        System.out.println("Aluno cadastrado!");
		        return aluno;
	        }
		        public static void imprimirLista(List<Aluno> lista) {
			        System.out.println("---------------------------------");
			        for (Aluno aluno : lista) {
			            aluno.imprimir();
	  }
	

   }
}

//a unica coisas que eu n�o use neste c�digo foi o foreach
//(eu honestamente prefiro o for tradicional e n�o entendo o foreach direito, se possivel use ele na proxima aula para me ajudar a entender)
