package programa1;

import java.util.ArrayList;
import java.util.List;


public class Aluno  {
	private String nome;
	private int idade;
	private String cpf; 
    private List<Telefone> telefones;
	
	
	public Aluno (String nome, int idade, String cpf ) {
		this.nome = nome;
		this.idade = idade;
		this.cpf = cpf;
		this.telefones = new ArrayList<>();
	}

	
	public String getNome() {
		return nome;
	}
	
	public String getCpf() {
		return cpf;
	}
	
	public int getIdade() {
		return idade;
	}
	
	public List<Telefone> getTelefones() {
		return telefones;
	}


	public void adicionarTelefone(Telefone telefone) {
        this.telefones.add(telefone);
    }
	
	
	public String toString() {
        String resultado = "Aluno [nome=" + nome + ", idade=" + idade + ", cpf=" + cpf + ", telefone=" + telefones + "]";
        
        for (Telefone t : telefones) {
            resultado += t.toString();
        }
		return resultado;
     }
		    
        public void imprimir() {
        	System.out.println(toString());
        }
		    


	
}
	


	
		
	
        
	

