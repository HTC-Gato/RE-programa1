package programa1;

public class Professor {
	public String cpf;
	public String nome;
	public Telefone telefone;
	public String endereco;

	
	//como n�o pediu pelos dados do professor, esta parte do c�digo ficara quieta por um tempo
}
